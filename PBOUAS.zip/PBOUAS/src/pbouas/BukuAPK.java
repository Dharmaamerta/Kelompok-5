/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pbouas;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Parent class PBOUAS
class PBOUAS {
    protected String title;
    protected String authorName;
    protected String publisher;
    protected int publicationYear;

    // Constructor
    public PBOUAS(String title, String authorName, String publisher, int publicationYear) {
        this.title = title;
        this.authorName = authorName;
        this.publisher = publisher;
        this.publicationYear = publicationYear;
    }

    // Method to display book information
    public String[] getBookInfo() {
        return new String[]{title, authorName, publisher, String.valueOf(publicationYear)};
    }
}

// Child class ChildrenBook
class ChildrenBook extends PBOUAS {
    public ChildrenBook(String title, String authorName, String publisher, int publicationYear) {
        super(title, authorName, publisher, publicationYear);
    }

    // Additional methods or overrides specific to Children's Books
}

// Child class TeenBook
class TeenBook extends PBOUAS {
    public TeenBook(String title, String authorName, String publisher, int publicationYear) {
        super(title, authorName, publisher, publicationYear);
    }

    // Additional methods or overrides specific to Teen Books
}

// Child class AdultBook
class AdultBook extends PBOUAS {
    public AdultBook(String title, String authorName, String publisher, int publicationYear) {
        super(title, authorName, publisher, publicationYear);
    }

    // Additional methods or overrides specific to Adult Books
}

// Main class BookStoreGUIApp as GUI Application
public class BukuAPK extends JFrame {

    private DefaultTableModel tableModel;
    private JTable table;

    public BukuAPK() {
        setTitle("Book Store Application");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the frame on the screen

        // Table setup
        String[] columnNames = {"Judul", "Pengarang", "Penerbit", "Tahun Terbit"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Button to add books
        JButton addButton = new JButton("Tambah Buku");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addBook();
            }
        });
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void addBook() {
        // Input data buku
        String title = JOptionPane.showInputDialog("Masukkan Judul Buku:");
        String authorName = JOptionPane.showInputDialog("Masukkan Nama Pengarang:");
        String publisher = JOptionPane.showInputDialog("Masukkan Penerbit:");
        int publicationYear = Integer.parseInt(JOptionPane.showInputDialog("Masukkan Tahun Terbit:"));
        char category = JOptionPane.showInputDialog("Masukkan Kategori (su/r/d/a):").charAt(0);

        PBOUAS newBook;
        switch (category) {
            case 'a':
                newBook = new ChildrenBook(title, authorName, publisher, publicationYear);
                break;
            case 'r':
                newBook = new TeenBook(title, authorName, publisher, publicationYear);
                break;
            case 'd':
                newBook = new AdultBook(title, authorName, publisher, publicationYear);
                break;
            default:
                newBook = new PBOUAS(title, authorName, publisher, publicationYear);
                break;
        }

        // Add book to table
        tableModel.addRow(newBook.getBookInfo());
    }

    public static void main(String[] args) {
        // Create and display the GUI
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                BukuAPK gui = new BukuAPK();
                gui.setVisible(true);
            }
        });
    }
}
